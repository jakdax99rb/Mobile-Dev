Run by opening in android studio. Then create your virtual device through AVD manager, select a nexus 5 with api 26. After that do the following Build > Make project. Run > Run App. Then enter your name and click either of the buttons.

